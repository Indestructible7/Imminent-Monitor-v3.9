If Imminent Monitor closes after executing, please try running it as Administrator.


If the installation fails or you have any questions or need support please contact "ImminentMonitorSupport", "shockwave.hf"


Thank you for purchasing Imminent Monitor